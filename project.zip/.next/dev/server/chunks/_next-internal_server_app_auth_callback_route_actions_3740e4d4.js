module.exports = [
"[project]/.next-internal/server/app/auth/callback/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_auth_callback_route_actions_3740e4d4.js.map